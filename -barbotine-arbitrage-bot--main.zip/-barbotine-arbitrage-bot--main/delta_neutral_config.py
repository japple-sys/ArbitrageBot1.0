# using fake-money mode? you don't need to fill anything here.

futures_exchange = "hyperliquid"

api_credentials = {
    'apiKey':'here',
    'secret':'here',
}
